package com.example.demo.Controller;

import java.util.List;

import javax.servlet.http.HttpSession;
import javax.swing.event.TableColumnModelListener;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.Entity.Vissa;
import com.example.demo.Service.VissaService;


@Controller
public class VissaController 
{
	@Autowired
	private VissaService  service;
	
	
	
	
	@GetMapping("/")
	public String home(Model m) 
	{
		

		List<Vissa> vissa=service.getAllVissa();
		m.addAttribute("vissa",vissa);
		
		return "index";
		
	}
	@GetMapping("/addvissa")
	public String addVissaForm()
	{
		return "add_vissa";
	}
	@PostMapping("/register")
	public String vissaRegister(@ModelAttribute Vissa e , HttpSession session)
	{
		System.out.println(e);
		
		service.addVissa(e);
		session.setAttribute("msg", "Details Added Succesfully...");
		
		
		return "redirect:/"; 
		
	}
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable int id ,Model m)
	{
		
		Vissa e=service.getvissaById(id);
		m.addAttribute("vissa", e);
		
		return "edit";
	}
	

}
