package com.example.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.Vissa;
import com.example.demo.Repository.VissaRepo;

@Service
public class VissaService 
{
	@Autowired
	private VissaRepo repo;
	public void addVissa(Vissa e)
	{
		repo.save(e);
		
	}
	public List<Vissa> getAllVissa()
	{
		return repo.findAll();
	}
	public Vissa getvissaById(int id)
	{
	 Optional<Vissa> e=repo.findById(id);
	 if(e.isPresent())
	 {
		 return e.get();
	 }
	 return null;
		
	}

}
