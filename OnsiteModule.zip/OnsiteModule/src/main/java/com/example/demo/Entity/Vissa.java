package com.example.demo.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="COM_SYSTEM")
public class Vissa 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name; 
	private int phone;
    private int vidate;
    private int flightdate;
    private int noofdaysissued;
    
    
    
    
    
	public Vissa() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public int getVidate() {
		return vidate;
	}
	public void setVidate(int vidate) {
		this.vidate = vidate;
	}
	public int getFlightdate() {
		return flightdate;
	}
	public void setFlightdate(int flightdate) {
		this.flightdate = flightdate;
	}
	public int getNoofdaysissued() {
		return noofdaysissued;
	}
	public void setNoofdaysissued(int noofdaysissued) {
		this.noofdaysissued = noofdaysissued;
	}
	@Override
	public String toString() {
		return "Vissa [id=" + id + ", name=" + name + ", phone=" + phone + ", vidate=" + vidate + ", flightdate="
				+ flightdate + ", noofdaysissued=" + noofdaysissued + "]";
	}
    
    

}
